<?php
include '../vendor/autoload.php';
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$user = noHacking(isset($data['user']) ? $data['user'] : '');
$number = noHacking(isset($data['number']) ? $data['number'] : '');
$amount = noHacking(isset($data['amount']) ? $data['amount'] : '100');


$date = datesimple();
$time_plan = 31;
$validate = date('Y-m-d', strtotime('+' . $time_plan . 'days', strtotime($date)));


$sql = "SELECT * FROM plans WHERE user_id='$user'";
$exec = mysqli_query($conn, $sql);
if (mysqli_num_rows($exec) > 0) {

  $response = array('status' => 409, 'message' => 'Você já tem um plano vamos redicionar você');

  echo json_encode($response);

} else {
  $result = payment($amount, $number);

  // $result = 200;

  if ($result->status == 200 || $result->status == 201) {
    // if ($result == 200) {
    // $response = array('status' => $result, 'message' => 'Pagamento efectuado com sucesso');

    $response = array('status' => $result->status, 'message' => 'Pagamento efectuado com sucesso');
    echo json_encode($response);

    $sql = "INSERT INTO plans (user_id, start_date, end_date) VALUES('$user', '$date', '$validate')";
    $exec = mysqli_query($conn, $sql);

    if (mysqli_affected_rows($conn) > 0) {
      // $response = array('status' => $result->status, 'message' => 'Plano registrado com sucesso');
      // print_r($response);
    } else {
      $response = array('status' => 500, 'message' => 'Registo de plano falhou');
      // print_r($response);
    }

  } else {
    // $response = array('status' => $result, 'message' => 'O Pagamento falhou, tente novamente');

    $response = array('status' => $result->status, 'message' => 'O Pagamento falhou, tente novamente');
    echo json_encode($response);
  }
}




mysqli_close($conn);
?>