<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();


$sql = "SELECT * FROM questions order by rand()";
$exec = mysqli_query($conn, $sql);


$results = array();

if (mysqli_num_rows($exec) > 0) {
  while ($data = mysqli_fetch_assoc($exec)) {
    $questions = array(
      'id' => intval($data['id']),
      'question' => $data['question'],
      'image' => $data['image'],
      'options' => getQuestionOptions(intval($data['id'])),

    );
    $results[] = $questions;

  }
  $response = array('status' => 200, 'questions' => $results);
  echo json_encode($response);

} else {
  $response = array('status' => 404, 'questions' => $results);
  echo json_encode($response);
}


mysqli_close($conn);
?>