<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$slug = noHacking(isset($_GET['slug']) ? $_GET['slug'] : '');

$sql = "SELECT shared.id,users.name AS user , shared.image,shared.slug FROM shared JOIN users ON shared.user_id=users.id WHERE shared.slug = '$slug'";
$exec = mysqli_query($conn, $sql);


$results = array();

if (mysqli_num_rows($exec) > 0) {
  while ($data = mysqli_fetch_assoc($exec)) {
    $shared = array(
      'id' => intval($data['id']),
      'user' => $data['user'],
      'image' => $data['image'],
      'slug' => $data['slug'],

    );
    $results[] = $shared;

  }
  $response = array('status' => 200, 'results' => $results[0]);
  echo json_encode($response);

} else {
  $response = array('status' => 404, 'result' => $results);
  echo json_encode($response);
}


mysqli_close($conn);
?>