<?php
include 'config.php';
include 'function.php';
mainHeader();

$json_data = json_decode($_POST['json_data'], true);

// $tk = noHacking(isset($json_data['token']) ? decodeHash($json_data['token']) : '');
$user = isset($json_data['user']) ? $json_data['user'] : '';


$date = datesimple();
$upload_dir = 'images/share';



if (!empty($_FILES['file'])) {

  $file_name = $_FILES["file"]["name"];
  $file_tmp_name = $_FILES["file"]["tmp_name"];
  $error = $_FILES["file"]["error"];

  if ($error > 0) {
    $response = array('status' => 401, 'message' => 'Erro enviando question');
    echo json_encode($response);
  } else {
    $random_name = 'share' . '-' . 'trafegotop' . '-' . $date . '-' . rand(1000, 1000000) * 3 . '.jpg';
    $upload_name = $upload_dir . '/' . strtolower($random_name);
    $upload_name = preg_replace('/\s+/', '-', $upload_name);

    if (move_uploaded_file($file_tmp_name, $upload_name)) {

      $path = $upload_name;
      $type = pathinfo($path, PATHINFO_EXTENSION);
      $data = file_get_contents($path);
      $base64Image = base64_encode($data);

      $name_to_slug = 'share' . '-' . 'trafegotop' . '-' . $date . '-' . rand(1000, 1000000) * 3 . '-' .$user;
      $slug = createUrlSlug($name_to_slug,$date);

      $sql = "INSERT INTO shared (`user_id`,`image`,`slug`) VALUES ('$user','$random_name','$slug')";

      $exec = mysqli_query($conn, $sql);
      if (mysqli_affected_rows($conn) == true) {

        $last_inserted_id = mysqli_insert_id($conn);
     
        $sql = "SELECT * FROM shared WHERE id='$last_inserted_id'";
        $exec=mysqli_query($conn,$sql);

        if(mysqli_num_rows($exec)>0){

            $data = mysqli_fetch_assoc($exec);

            $response = array('status' => 200, 'message' => 'sucesso','slug'=>$data['slug']);
            echo json_encode($response);

        }else{
            $response = array('status' => 404, 'message' => 'Shared Link not found');
            echo json_encode($response);
        }


      } else {
        $php_error = error_get_last();

        $response = array('status' => 500, 'message' => 'Erro adding shared information','php_error'=>$php_error);
        echo json_encode($response);

      }

    } else {
      $php_error = error_get_last();
      $response = array('status' => 500, 'message' => 'Erro uploading file','php_error'=>$php_error);
      echo json_encode($response);
    }
  }
} else {
  $php_error = error_get_last();

    $response = array('status' => 500, 'message' => 'No image attached file','php_error'=>$php_error);
    echo json_encode($response);
}

?>