<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$email = noHacking(isset($data['email']) ? $data['email'] : '');
$password = noHacking(isset($data['password']) ? $data['password'] : '');




$sql = "SELECT * FROM users WHERE email='$email'";
$exec = mysqli_query($conn, $sql);


if (mysqli_num_rows($exec) > 0) {

  $data = mysqli_fetch_assoc($exec);
  $hash = $data['password'];


  if (password_verify($password, $hash)) {
    unset($data['password']);

    $response = array('status' => 200, 'user' => $data, 'message' => 'Login efetuado com sucesso.');
    echo json_encode($response);
  } else {

    $response = array('status' => 401, 'message' => 'Usuario ou senha invalida');
    echo json_encode($response);
  }
} else {

  $response = array('status' => 401, 'message' => 'Usuario ou senha invalida');
  echo json_encode($response);
}


mysqli_close($conn);
?>