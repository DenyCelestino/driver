<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$name = noHacking(isset($data['name']) ? $data['name'] : '');
$email = noHacking(isset($data['email']) ? $data['email'] : '');
$google_id = noHacking(isset($data['google_id']) ? $data['google_id'] : '');

$date = datesimple();




$sql = "SELECT * FROM users WHERE google_id='$google_id' OR email='$email'";
$exec = mysqli_query($conn, $sql);

if (mysqli_num_rows($exec) > 0) {
    $response = array('status' => 401, 'message' => 'Já existe um usuário com esse email cadastrado, por favor tente usar um diferente.');
    echo json_encode($response);

} else {
    $sql = "INSERT INTO users (`name`,`email`,`google_id`,`isgoogle`,`date`) VALUES ('$name','$email','$google_id','1','$date')";
    $exec = mysqli_query($conn, $sql);

    if (mysqli_affected_rows($conn) == true) {
        $response = array('status' => 200, 'message' => 'Cadastro efectuado com sucesso.');


        $result = array();

        $sql = "SELECT * FROM users WHERE google_id='$google_id'";
        $exec = mysqli_query($conn, $sql);
        if (mysqli_num_rows($exec) > 0) {
            $user = mysqli_fetch_assoc($exec);


            $response = array("status" => 200, "message" => "Login efectuado com sucesso.", "user" => $user);
            echo json_encode($response);

        } else {
            $response = array("status" => 400, "message" => "Erro ao buscar dados.");
            echo json_encode($response);
        }


    } else {
        $response = array('status' => 500, 'message' => 'Erro criando conta.');
        echo json_encode($response);
    }
}


mysqli_close($conn);
?>