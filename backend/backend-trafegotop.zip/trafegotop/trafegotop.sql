-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 16/11/2023 às 10:32
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `trafegotop`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `options`
--

CREATE TABLE `options` (
  `id` bigint(20) NOT NULL,
  `question_id` bigint(20) NOT NULL,
  `option_description` text NOT NULL,
  `iscorrect` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `options`
--

INSERT INTO `options` (`id`, `question_id`, `option_description`, `iscorrect`) VALUES
(45, 18, 'SENTIDO PROIBIDO.', 1),
(46, 18, 'SENTIDO APROVADO.', 0),
(47, 18, 'PARAGEM OBRIGATORIA.', 0),
(48, 18, 'REDUZIR A 10KM/H', 0),
(49, 19, 'Proibição de virar à direita.', 1),
(50, 19, 'Proibição de virar à esquerda.', 0),
(51, 19, 'Proibição de ultrapassagem.', 0),
(52, 19, 'Proibição de reduzir.', 0),
(53, 20, 'Proibição de exceder a velocidade máxima de.', 1),
(54, 20, 'Aceite exceder a velocidade máxima de.', 0),
(55, 20, 'Proibição de alcancar a velocidade máxima de.', 0),
(56, 20, 'Proibição de exceder a menos da velocidade máxima de.', 0),
(57, 21, 'Proibição de ultrapassar.', 1),
(58, 21, 'Admissão de ultrapassar.', 0),
(59, 21, 'Proibição de ficar lado a lado.', 0),
(60, 21, 'Admissão de ficar lado a lado.', 0),
(61, 22, 'Proibido mudar de faixa ou pista de trânsito da esquerda para direita', 1),
(62, 22, 'Proibido mudar de faixa ou pista de trânsito da esquerda para esquerda.', 0),
(63, 22, 'Proibido fazer ultrapassagem.', 0),
(64, 22, 'Proibido mudar de faixa ou pista de trânsito da direita para esquerda', 0),
(65, 23, 'Trânsito proibido a automóveis de mercadorias de peso total superior a ...t', 1),
(66, 23, 'Trânsito proibido a automóveis de mercadorias de peso total nao superior a ...t', 0),
(67, 24, 'Trânsito proibido a automóveis de mercadorias de peso total superior a ...t', 1),
(68, 24, 'Trânsito proibido a automóveis de mercadorias de peso total nao superior a ...t', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `plans`
--

CREATE TABLE `plans` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `plans`
--

INSERT INTO `plans` (`id`, `user_id`, `start_date`, `end_date`) VALUES
(19, 19, '2023-11-13', '2023-11-17');

-- --------------------------------------------------------

--
-- Estrutura para tabela `questions`
--

CREATE TABLE `questions` (
  `id` bigint(20) NOT NULL,
  `question` text NOT NULL,
  `image` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `questions`
--

INSERT INTO `questions` (`id`, `question`, `image`) VALUES
(18, 'Para que serve esse sinal ?', 'growskills-trafegotop-2023-10-26-2392203.jpg'),
(19, 'Para que serve esse sinal ?', 'growskills-trafegotop-2023-10-26-971436.jpg'),
(20, 'Para que serve esse sinal ?', 'growskills-trafegotop-2023-10-26-2152641.jpg'),
(21, 'Para que serve esse sinal ?', 'growskills-trafegotop-2023-10-26-1974006.jpg'),
(22, 'Para que serve esse simbolo?', 'growskills-trafegotop-2023-10-31-2200947.jpg'),
(23, 'Para que serve esse simbolo ?', 'growskills-trafegotop-2023-11-01-894612.jpg'),
(24, 'Para que serve esse simbolo ?', 'growskills-trafegotop-2023-11-01-1141575.jpg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `shared`
--

CREATE TABLE `shared` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `image` text NOT NULL,
  `slug` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `number` text DEFAULT NULL,
  `google_id` text DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `isgoogle` tinyint(1) NOT NULL DEFAULT 0,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `number`, `google_id`, `avatar`, `password`, `isgoogle`, `date`) VALUES
(19, 'Delfim Celestino Amisse Pastola', 'denycelestino21@gmail.com', '846860296', '107723718688014586675', 'avatar-growskills-trafegotop-2023-11-08-459747.jpg', NULL, 1, '2023-11-08');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `options_ibfk_1` (`question_id`);

--
-- Índices de tabela `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Índices de tabela `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `shared`
--
ALTER TABLE `shared`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `options`
--
ALTER TABLE `options`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT de tabela `plans`
--
ALTER TABLE `plans`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `shared`
--
ALTER TABLE `shared`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `plans`
--
ALTER TABLE `plans`
  ADD CONSTRAINT `plans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Restrições para tabelas `shared`
--
ALTER TABLE `shared`
  ADD CONSTRAINT `shared_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
