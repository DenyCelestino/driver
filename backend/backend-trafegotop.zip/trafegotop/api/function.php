<?php
include '../vendor/autoload.php';
require '../vendor/firebase/php-jwt/src/JWT.php';
require '../vendor/firebase/php-jwt/src/Key.php';
include 'config.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;


$config = json_decode(file_get_contents('mnbvcxzlkjhgfdsapoiuytrewq.json'), true);

$apiKey = $config['API_KEY'];
$publicKey = $config['PUBLIC_KEY'];



$key = 'deny_celestino_844505131_kajdbksjdkasbdaksdjakdskj';

function datenow()
{
  return date('Y-m-d H:i:s');
}

function datesimple()
{
  return date('Y-m-d');
}

function noHacking($input)
{
  global $conn;
  $var = mysqli_escape_string($conn, $input);
  $var = htmlspecialchars($var);
  return $var;
}

function mainHeader()
{
  // https://joobei.vercel.app

  header('Access-Control-Allow-Origin:*');
  header('Content-type: application/json');
}

function encodeHash($hash)
{
  global $key;
  return JWT::encode($hash, $key, 'HS256');
}

function decodeHash($value)
{
  global $key;
  return JWT::decode($value, new Key($key, 'HS256'));
}
function createUrlSlug($name, $date)
{
  $random = random_int(0, 9999999999) . '-' . $date;
  $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $name);
  $slug2 = preg_replace('/[^A-Za-z0-9-]+/', '-', $random);
  return strtolower($slug . '-' . $slug2);
}


function getQuestionOptions($id)
{
  global $conn;

  $sql = "SELECT * FROM options WHERE question_id = '$id' ORDER BY RAND()";
  $exec = mysqli_query($conn, $sql);
  $questions = array();

  while ($data = mysqli_fetch_assoc($exec)) {
    $results = array(
      'id' => intval($data['id']),
      'option' => $data['option_description'],
      'iscorrect' => boolval($data['iscorrect']),

    );
    $questions[] = $results;

  }
  return $questions;

}

function payment($amount, $number)
{

  global $apiKey, $publicKey;

  $mpesa = new \Karson\MpesaPhpSdk\Mpesa();
  $mpesa->setApiKey($apiKey);
  $mpesa->setPublicKey($publicKey);

  $mpesa->setServiceProviderCode('171717');
  $mpesa->setEnv('test'); // 'live' production environment 

  //This creates a transaction between an M-Pesa service provider code to a phone number registered on M-Pesa.
  $invoice_id = "T1234462"; // Eg: Invoice number
  $prefix = 258;
  $phone_number = $prefix . $number; // Prefixed with the country code (258)
  $amount = floatval($amount); // Payment amount
  $reference_id = substr(1222 . bin2hex(random_bytes(5)), 0, 10); //111PA2D


  $result = $mpesa->c2b($invoice_id, $phone_number, $amount, $reference_id);





  return $result;
}


?>