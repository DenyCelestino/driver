<?php
include 'config.php';
include 'function.php';
mainHeader();

$json_data = json_decode($_POST['json_data'], true);

// $tk = noHacking(isset($json_data['token']) ? decodeHash($json_data['token']) : '');
$question = noHacking(isset($json_data['question']) ? $json_data['question'] : '');
$options = isset($json_data['options']) ? $json_data['options'] : '';


$date = datesimple();
$upload_dir = 'images/question';



if (!empty($_FILES['file'])) {

  $file_name = $_FILES["file"]["name"];
  $file_tmp_name = $_FILES["file"]["tmp_name"];
  $error = $_FILES["file"]["error"];

  if ($error > 0) {
    $response = array('status' => 401, 'message' => 'Erro enviando question');
    echo json_encode($response);
  } else {
    $random_name = 'growskills' . '-' . 'trafegotop' . '-' . $date . '-' . rand(1000, 1000000) * 3 . '.jpg';
    $upload_name = $upload_dir . '/' . strtolower($random_name);
    $upload_name = preg_replace('/\s+/', '-', $upload_name);

    if (move_uploaded_file($file_tmp_name, $upload_name)) {

      $path = $upload_name;
      $type = pathinfo($path, PATHINFO_EXTENSION);
      $data = file_get_contents($path);
      $base64Image = base64_encode($data);


      $sql = "INSERT INTO questions (`question`,`image`) VALUES ('$question','$random_name')";

      $exec = mysqli_query($conn, $sql);
      if (mysqli_affected_rows($conn) == true) {

        $last_inserted_id = mysqli_insert_id($conn);
        $response = array('status' => 200, 'message' => 'Question added successfully');
        echo json_encode($response);
        foreach ($options as $option) {

          $sql = "INSERT INTO options (`question_id`,`option_description`,`iscorrect`) VALUES ('$last_inserted_id','$option[text]','$option[iscorrect]')";
          $exec = mysqli_query($conn, $sql);
          if (mysqli_affected_rows($conn) == true) {

          } else {

            if (file_exists($upload_name) == true) {

              unlink($upload_name);
            }

            $response = array('status' => 500, 'message' => 'Error adding options');
            echo json_encode($response);
          }

        }



      } else {
        $response = array('status' => 500, 'message' => 'Erro adding question');
        echo json_encode($response);

      }

    } else {
      $response = array('status' => 500, 'message' => 'Erro uploading file');
      echo json_encode($response);
    }
  }
} else {
  $sql = "INSERT INTO questions (`question`) VALUES ('$question')";

  $exec = mysqli_query($conn, $sql);
  if (mysqli_affected_rows($conn) == true) {

    $last_inserted_id = mysqli_insert_id($conn);
    $response = array('status' => 200, 'message' => 'Question added successfully');
    echo json_encode($response);
    foreach ($options as $option) {

      $sql = "INSERT INTO options (`question_id`,`option_description`,`iscorrect`) VALUES ('$last_inserted_id','$option[text]','$option[iscorrect]')";
      $exec = mysqli_query($conn, $sql);
      if (mysqli_affected_rows($conn) == true) {

      } else {

        $response = array('status' => 500, 'message' => 'Error adding options');
        echo json_encode($response);
      }

    }



  } else {
    $response = array('status' => 500, 'message' => 'Erro adding question');
    echo json_encode($response);

  }
}

?>