<?php
include '../vendor/autoload.php';
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$name = noHacking(isset($data['name']) ? $data['name'] : '');
$email = noHacking(isset($data['email']) ? $data['email'] : '');
$number = noHacking(isset($data['number']) ? $data['number'] : '');
$password = noHacking(isset($data['password']) ? $data['password'] : '');


if (!empty($password)) {

  $hash = password_hash($password, PASSWORD_BCRYPT);

  $sql = "UPDATE users set password = '$hash' , number = '$number', name = '$name' WHERE email = '$email'";
  $result = mysqli_query($conn, $sql);
  if (mysqli_affected_rows($conn) == 1) {

    $sql = "SELECT * FROM `users` WHERE email = '$email'";
    $exec = mysqli_query($conn, $sql);


    if (mysqli_num_rows($exec) > 0) {

      $data = mysqli_fetch_assoc($exec);
      unset($data['password']);
      // unset($data['outra_coluna_a_ser_excluida']);
      $response = array('status' => 200, 'user' => $data, 'message' => 'Dados actualizados com sucesso');
      echo json_encode($response);
    } else {

      $response = array('status' => 404, 'message' => 'User not found');
      echo json_encode($response);
    }


  } else {
    $response = array('status' => 500, 'message' => 'Erro actualizando informacão');
    echo json_encode($response);
  }


} else {

  $sql = "UPDATE users set number = '$number', name = '$name' WHERE email = '$email'";
  $result = mysqli_query($conn, $sql);
  if (mysqli_affected_rows($conn) == 1) {

    $sql = "SELECT * FROM `users` WHERE email = '$email'";
    $exec = mysqli_query($conn, $sql);


    if (mysqli_num_rows($exec) > 0) {

      $data = mysqli_fetch_assoc($exec);
      unset($data['password']);
      // unset($data['outra_coluna_a_ser_excluida']);
      $response = array('status' => 200, 'user' => $data, 'message' => 'Dados actualizados com sucesso');
      echo json_encode($response);
    } else {

      $response = array('status' => 404, 'message' => 'User not found');
      echo json_encode($response);
    }


  } else {
    $response = array('status' => 500, 'message' => 'Erro actualizando informacão');
    echo json_encode($response);
  }
}




?>