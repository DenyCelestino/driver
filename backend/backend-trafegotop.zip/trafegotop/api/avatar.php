<?php
include 'config.php';
include 'function.php';
mainHeader();

$json_data = json_decode($_POST['json_data'], true);

$email = noHacking(isset($json_data['email']) ? $json_data['email'] : '');
$oldavatar = noHacking(isset($json_data['oldavatar']) ? $json_data['oldavatar'] : '');


$date = datesimple();
$upload_dir = 'images/avatar';



if (!empty($_FILES['file'])) {

  $file_name = $_FILES["file"]["name"];
  $file_tmp_name = $_FILES["file"]["tmp_name"];
  $error = $_FILES["file"]["error"];

  if ($error > 0) {
    $response = array('status' => 401, 'message' => 'Erro enviando avatar');
    echo json_encode($response);
  } else {
    $random_name = 'avatar-growskills' . '-' . 'trafegotop' . '-' . $date . '-' . rand(1000, 1000000) * 3 . '.jpg';
    $upload_name = $upload_dir . '/' . strtolower($random_name);
    $upload_name = preg_replace('/\s+/', '-', $upload_name);

    if (move_uploaded_file($file_tmp_name, $upload_name)) {

      $path = $upload_name;
      $type = pathinfo($path, PATHINFO_EXTENSION);
      $data = file_get_contents($path);
      $base64Image = base64_encode($data);


      $sql = "UPDATE users set avatar='$random_name' WHERE email='$email'";

      $exec = mysqli_query($conn, $sql);
      if (mysqli_affected_rows($conn) == true) {


        if ($oldavatar != '') {
          if (file_exists($upload_dir . '/' . $oldavatar)) {
            unlink($upload_dir . '/' . $oldavatar);
          }
        }

        $sql = "SELECT * FROM `users` WHERE email = '$email'";
        $exec = mysqli_query($conn, $sql);


        if (mysqli_num_rows($exec) > 0) {

          $data = mysqli_fetch_assoc($exec);
          unset($data['password']);
          // unset($data['outra_coluna_a_ser_excluida']);
          $response = array('status' => 200, 'user' => $data);
          echo json_encode($response);
        } else {

          $response = array('status' => 401, 'message' => 'User not found');
          echo json_encode($response);
        }

      } else {
        $response = array('status' => 500, 'message' => 'Erro adding Avatar');
        echo json_encode($response);

      }

    } else {
      $php_error = error_get_last();

      $response = array('status' => 500, 'message' => 'Erro uploading file', 'php_error' => $php_error['message']);
      echo json_encode($response);


    }
  }
} else {
  $response = array('status' => 500, 'message' => 'No file uploaded');
  echo json_encode($response);
}

?>