<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$email = noHacking(isset($data['email']) ? $data['email'] : '');
$google_id = noHacking(isset($data['google_id']) ? $data['google_id'] : '');



$sql = "SELECT * FROM `users` WHERE google_id = '$google_id' AND email = '$email'";
$exec = mysqli_query($conn, $sql);


if (mysqli_num_rows($exec) > 0) {

  $data = mysqli_fetch_assoc($exec);
  unset($data['password']);
  // unset($data['outra_coluna_a_ser_excluida']);
  $response = array('status' => 200, 'user' => $data);
  echo json_encode($response);
} else {

  $response = array('status' => 404, 'message' => 'User not found');
  echo json_encode($response);
}


mysqli_close($conn);
?>