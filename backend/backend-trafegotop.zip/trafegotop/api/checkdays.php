<?php
include '../vendor/autoload.php';
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$user = noHacking(isset($_GET['user']) ? $_GET['user'] : '');

$sql = "SELECT * FROM plans WHERE user_id='$user'";
$exec = mysqli_query($conn, $sql);




if (mysqli_num_rows($exec) > 0) {
  $data = mysqli_fetch_assoc($exec);

  if ($data['end_date'] < date('Y-m-d')) {
    $sql = "DELETE FROM plans WHERE user_id='$user'";
    $exec = mysqli_query($conn, $sql);
    if (mysqli_affected_rows($conn) > 0) {
      $response = array('status' => 404, 'message' => 'No plan available');
      echo json_encode($response);
    }

  } else {
    $start_date = new DateTime($data['start_date']);
    $end_date = new DateTime($data['end_date']);

    $interval = $start_date->diff($end_date);
    $days = $interval->format('%a'); // Retorna a diferença em dias


    $response = array('status' => 200, 'days' => $days);

    echo json_encode($response);
  }




} else {
  $response = array('status' => 404, 'message' => 'No plan available');
  echo json_encode($response);
}

mysqli_close($conn);
?>