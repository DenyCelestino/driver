<?php
include 'config.php';
include 'function.php';
$url = file_get_contents('php://input');
$data = json_decode($url, true);
mainHeader();

$name = noHacking(isset($data['name']) ? $data['name'] : '');
$email = noHacking(isset($data['email']) ? $data['email'] : '');
$number = noHacking(isset($data['number']) ? $data['number'] : '');
$password = noHacking(isset($data['password']) ? $data['password'] : '');

$date = datesimple();


$hash = password_hash($password, PASSWORD_BCRYPT);


$sql = "SELECT * FROM users WHERE email='$email'";
$exec = mysqli_query($conn, $sql);

if (mysqli_num_rows($exec) > 0) {
  $response = array('status' => 401, 'message' => 'Já existe um usuário com esse email cadastrado, por favor tente usar um diferente.');
  echo json_encode($response);

} else {
  $sql = "INSERT INTO users (`name`,`email`,`number`,`password`,`date`) VALUES ('$name','$email','$number','$hash','$date')";
  $exec = mysqli_query($conn, $sql);

  if (mysqli_affected_rows($conn) == true) {

    $sql = "SELECT * FROM users WHERE email='$email'";
    $exec = mysqli_query($conn, $sql);
    if (mysqli_num_rows($exec) > 0) {
      $data = mysqli_fetch_assoc($exec);
      unset($data['password']);
      // unset($data['outra_coluna_a_ser_excluida']);

      $response = array('status' => 200, 'message' => 'Cadastro efectuado com sucesso.', 'user' => $data);
      echo json_encode($response);
    }

  } else {
    $response = array('status' => 500, 'message' => 'Erro criando conta.');
    echo json_encode($response);
  }
}


mysqli_close($conn);
?>